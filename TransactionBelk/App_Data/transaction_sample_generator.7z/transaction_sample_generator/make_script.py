#!/usr/bin/python3

import os
import re
import math
from random import randint

def generate_long_num(legth):
	result = ''
	while legth > 0:
		legth = legth-1
		number = randint(0, 9)
		result = result + str(number)

	return result


def generate_email(name):
	fname, surname = name.split(None)
	result = fname[0:3] + "_" + surname[0:3] + "@gmail.com"
	return result

def generate_created():
	result = ''
	year = str(randint(1990, 2015))
	result = result + year
	month = zero_num(12)
	result = result + '.' + month
	if month != '02':
		day = zero_num(30)
	else:
		day = zero_num(28)
	result = result + '.' + day + " "
	hour = zero_num(23)
	result = result + hour
	minute = zero_num(59)
	result = result + ':' + str(minute)
	second = zero_num(59)
	result = result + ':' + str(second)

	return result

def get_resources(rel_file_path):
	result = []
	path_name = os.path.dirname(__file__) + rel_file_path
	with open(path_name, encoding='utf-8') as names_file:
 		for name in names_file:
 			result.append(name)

 		return result
	

def zero_num(max):
	result = randint(1, max)
	if result < 10:
		result = '0' + str(result)
	return str(result)

names = get_resources('/res/names.txt')
surnames = get_resources('/res/surnames.txt')

fullnames = []

i = 0
while i<4000:
	lenname = len(names) - 1
	len_surname = len(surnames) - 1
	# print(lenname)
	fullname = names[randint(0, lenname)] + ' ' + surnames[randint(0, len_surname)]
	fullname = fullname.replace('\n', '')
	# print(fullname)
	fullnames.append(fullname)
	i = i + 1

senders = set(fullnames)
# print(len(senders))

if math.fmod(len(senders), 2) != 0:
	i = len(senders) -1
	senders.pop()

receivers = set()
i = len(senders)/2
while i>0:
	i = i - 1
	receivers.add(senders.pop())


pairs = set()

while (len(senders) != 0):
	sender = senders.pop()
	pairs.add("INSERT INTO dbo.Transactions (sender, receiver, bankNumberSender, emailSender, phoneSender, createdTimestamp, isDeleted, TransactionStatusId) values (\'" + sender + "\', \'" + receivers.pop() + 
		"\', \'" + generate_long_num(17) + "\', \'" + generate_email(sender) + "\', \'+" + generate_long_num(10) + "\', \'" + generate_created() + "\', " + "0," + " 1" +");\n")


inserts = os.path.dirname(__file__) + "/result.sql"
# print(os.getcwd())
counter = 1
if os.path.isfile(inserts):
	while os.path.isfile(inserts):
		inserts = os.path.dirname(__file__) + "/result" + str(counter) + ".sql"
		counter = counter + 1

result_file = open(inserts, 'w+', encoding = 'utf-8')
for pair in pairs:
	result_file.write(pair)